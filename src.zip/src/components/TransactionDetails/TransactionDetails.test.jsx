import React from "react";
// jest-dom matchers are registered globally via src/setupTests.js
import { render, screen } from "@testing-library/react";
import TransactionDetails from "./TransactionDetails";

describe("TransactionDetails", () => {
  test("renders transaction rows and computes points correctly", () => {
    const transactions = [
      { id: 1, date: "2025-08-15", amount: 120 }, // points = 90
      { id: 2, date: "2025-08-20", amount: 75 },  // points = 25
    ];

    render(<TransactionDetails transactions={transactions} />);

    // amounts (toFixed)
    expect(screen.getByText("120.00")).toBeInTheDocument();
    expect(screen.getByText("75.00")).toBeInTheDocument();

    // computed points appear in the table
    expect(screen.getByText("90")).toBeInTheDocument();
    expect(screen.getByText("25")).toBeInTheDocument();

    // header present (uses translation constant)
    expect(screen.getByText(/Transaction Breakdown/i)).toBeInTheDocument();
  });
});
