import React from "react";
import PropTypes from "prop-types";
import { calculatePoints } from "../../utils/rewardUtils";
import { translate } from "../../constant/constant";
import "./TransactionDetails.css";

const TransactionDetails = ({ transactions }) => {
  const list = Array.isArray(transactions) ? transactions : [];
  return (
    <div>
      <h4>{translate("TRANSACTION_BREAKDOWN")}</h4>
      <table className="transaction-table">
        <thead>
          <tr>
            <th>{translate("DATE")}</th>
            <th>{translate("AMOUNT")}</th>
            <th>{translate("POINTS_EARNED")}</th>
          </tr>
        </thead>
        <tbody>
          {list.map(({ date, amount = 0, points }, rowIndex) => {
            const pts = typeof points === "number" ? points : calculatePoints(Number(amount) || 0);
            const displayDate = date ? new Date(date).toLocaleDateString() : "N/A";
            return (
              <tr key={rowIndex}>
                <td>{displayDate}</td>
                <td>{Number(amount).toFixed(2)}</td>
                <td>{pts}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

TransactionDetails.propTypes = {
  transactions: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      date: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Date)]),
      amount: PropTypes.number,
      points: PropTypes.number,
    })
  ),
};

TransactionDetails.defaultProps = {
  transactions: [],
};

export default TransactionDetails;