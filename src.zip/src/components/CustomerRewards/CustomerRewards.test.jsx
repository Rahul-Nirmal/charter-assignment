import React from "react";
import { render, screen } from "@testing-library/react";
import CustomerRewards from "./CustomerRewards";

describe("CustomerRewards", () => {
  test("renders customer name, monthly list, transactions and totals", () => {
    const props = {
      customer: "Alice",
      monthlyPoints: [
        { month: "May 2025", points: 100 },
        { month: "Jun 2025", points: 50 },
      ],
      transactions: [
        { id: 1, date: "2025-05-10", amount: 85 },
        { id: 2, date: "2025-06-14", amount: 60 },
      ],
      totalSpend: 145,
      totalPoints: 150,
    };

    render(<CustomerRewards {...props} />);

    expect(screen.getByText("Alice")).toBeInTheDocument();
    // monthly items
    expect(screen.getByText(/May 2025/i)).toBeInTheDocument();
    expect(screen.getByText(/100 points/i)).toBeInTheDocument();
    // transaction amounts from child TransactionDetails
    expect(screen.getByText("85.00")).toBeInTheDocument();
    expect(screen.getByText("60.00")).toBeInTheDocument();
    // totals
    expect(screen.getByText(/Total Spend/i)).toBeInTheDocument();
    expect(screen.getByText(/\$145/)).toBeInTheDocument();
    expect(screen.getByText(/Total Points/i)).toBeInTheDocument();
    expect(screen.getByText(/150/)).toBeInTheDocument();
  });

  test("accepts alternate monthly shape (monthly with label/monthKey)", () => {
    const props = {
      customer: "Bob",
      monthly: [
        { monthKey: "2025-05", label: "May 2025", points: 40 },
      ],
      transactions: [],
    };

    render(<CustomerRewards {...props} />);

    expect(screen.getByText("Bob")).toBeInTheDocument();
    expect(screen.getByText(/May 2025/i)).toBeInTheDocument();
    expect(screen.getByText(/40 points/i)).toBeInTheDocument();
  });
});
