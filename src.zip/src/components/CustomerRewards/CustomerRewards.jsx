import React, { useState } from "react";
import MonthlyPointsList from "../MonthlyPointsList/MonthlyPointsList";
import TransactionDetails from "../TransactionDetails/TransactionDetails";
import PropTypes from "prop-types";
import { translate } from "../../constant/constant";

const CustomerRewards = (props) => {
  const {
    customer = "",
    monthlyPoints, // preferred prop
    monthly, // alternative shape from rewardUtils
    totalPoints,
    totalRewards,
    totalSpend,
    transactions = [],
  } = props;

  const [expanded, setExpanded] = useState(false);

  // normalize monthly list to shape: { month: string, points: number }
  const monthlyList = (monthlyPoints && monthlyPoints.length)
    ? monthlyPoints
    : (Array.isArray(monthly) ? monthly.map(monthItem => ({
        month: monthItem.label ?? monthItem.month ?? monthItem.monthKey ?? "Unknown",
        points: monthItem.points ?? 0
      })) : []);

  // compute totals if not provided
  const computedTotalPoints = typeof totalPoints === "number"
    ? totalPoints
    : (typeof totalRewards === "number"
      ? totalRewards
      : monthlyList.reduce((s, it) => s + (it.points || 0), 0));

  const computedTotalSpend = (typeof totalSpend === "number" && !Number.isNaN(totalSpend))
    ? totalSpend
    : transactions.reduce((s, tx) => s + (Number(tx.amount) || 0), 0);

  return (
    <div>
      <h3>{customer}</h3>

      {/* Monthly points as table */}
      <MonthlyPointsList monthlyPoints={monthlyList} />

      {/* Expand/collapse transaction details */}
      <div>
        <button
          className="toggle-transactions"
          type="button"
          aria-expanded={expanded}
          onClick={() => setExpanded(prev => !prev)}
        >
          {expanded ? "Hide transactions" : `Show transactions (${transactions.length})`}
        </button>
      </div>
      {expanded && (
        <div
          id={`transactions-${String(customer || "").replace(/\s+/g, "-").toLowerCase()}`}
          className="transaction-panel"
        >
          <TransactionDetails transactions={transactions} />
        </div>
      )}

      <p><strong>{translate("TOTAL_SPEND")}: ${computedTotalSpend}</strong></p>
      <p><strong>{translate("TOTAL_POINTS")}: {computedTotalPoints}</strong></p>
      <hr />
    </div>
  );
};

CustomerRewards.propTypes = {
  customer: PropTypes.string,
  // monthlyPoints: preferred shape for UI components
  monthlyPoints: PropTypes.arrayOf(
    PropTypes.shape({
      month: PropTypes.string.isRequired,
      points: PropTypes.number.isRequired,
    })
  ),
  // monthly: alternative from rewardUtils ({ monthKey, label, points })
  monthly: PropTypes.arrayOf(
    PropTypes.shape({
      monthKey: PropTypes.string,
      label: PropTypes.string,
      points: PropTypes.number,
    })
  ),
  totalPoints: PropTypes.number,
  totalRewards: PropTypes.number,
  totalSpend: PropTypes.number,
  transactions: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      date: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Date)]),
      amount: PropTypes.number,
    })
  ),
};

CustomerRewards.defaultProps = {
  customer: "",
  monthlyPoints: [],
  monthly: [],
  totalPoints: undefined,
  totalRewards: undefined,
  totalSpend: undefined,
  transactions: [],
};

export default CustomerRewards;