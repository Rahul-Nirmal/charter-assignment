import React from "react";
import { render, screen } from "@testing-library/react";

// mock the transactions hook used by RewardsTable
jest.mock("../../hooks/useTransactions", () => ({
  __esModule: true,
  default: () => ({ transactions: [], loading: false, error: null }),
}));

// mock the grouping util to return predictable grouped data
jest.mock("../../utils/rewardUtils", () => ({
  __esModule: true,
  groupByCustomer: jest.fn(() => [
    {
      customer: "Alice",
      monthly: [{ monthKey: "2025-05", label: "May 2025", points: 100 }],
      transactions: [{ id: 1, date: "2025-05-10", amount: 85 }],
      totalRewards: 100,
    },
    {
      customer: "Bob",
      monthly: [{ monthKey: "2025-06", label: "Jun 2025", points: 50 }],
      transactions: [{ id: 2, date: "2025-06-14", amount: 60 }],
      totalRewards: 50,
    },
  ]),
}));

// Mock the lazily imported CustomerRewards component so tests don't depend on dynamic import timing
jest.mock("../CustomerRewards/CustomerRewards", () => {
  // require inside factory to avoid referencing out-of-scope variables
  const ReactInsideMock = require("react");
  return {
    __esModule: true,
    default: (props) => ReactInsideMock.createElement("div", null, props.customer),
  };
});

import RewardsTable from "./RewardsTable";

describe("RewardsTable", () => {
  test("renders header and customer sections from grouped data", async () => {
    render(React.createElement(RewardsTable, null));

    // header (translation uses constant; assert visible)
    expect(screen.getByText(/Customer Rewards Summary/i)).toBeInTheDocument();

    // await the mocked customer components to render their customer names
    expect(await screen.findByText("Alice")).toBeInTheDocument();
    expect(await screen.findByText("Bob")).toBeInTheDocument();
  });
});
