import React, { useEffect, useState, Suspense, lazy } from "react";
import { groupByCustomer } from "../../utils/rewardUtils";
import useTransactions from "../../hooks/useTransactions";
import { translate } from "../../constant/constant";
import "./RewardsTable.css";
const CustomerRewards = lazy(() => import("../CustomerRewards/CustomerRewards"));


const RewardsTable = () => {
  const [rewards, setRewards] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(""); // track dropdown selection
  const [searchTerm, setSearchTerm] = useState(""); // track search input
  const [suggestionsVisible, setSuggestionsVisible] = useState(false); // control suggestion list visibility

  const { transactions, loading, error } = useTransactions(
    "/data/transactions.json"
  );

  useEffect(() => {
    if (!loading && !error) {
      setRewards(groupByCustomer(transactions));
    }
    if (error) {
      setRewards([]);
    }
  }, [transactions, loading, error]);

  // build list of customer names for the dropdown
  const customerNames = Array.isArray(rewards) ? rewards.map(r => r.customer) : [];

  // filter customers by search term (case-insensitive)
  const filteredCustomerNames = searchTerm
    ? customerNames.filter(name => name.toLowerCase().includes(searchTerm.toLowerCase()))
    : customerNames;

  const handleChange = (e) => {
    setSelectedCustomer(e.target.value);
    // clear previous search and suggestions when user is changed via dropdown
    setSearchTerm("");
    setSuggestionsVisible(false);
  };

  const handleSearchChange = (e) => {
    const v = e.target.value;
    setSearchTerm(v);
    setSuggestionsVisible(Boolean(v) && filteredCustomerNames.length > 0);
  };

  const handleSearchFocus = () => {
    if (searchTerm && filteredCustomerNames.length > 0) setSuggestionsVisible(true);
  };

  const handleSearchBlur = () => {
    // small delay to allow clicking suggestion (use onMouseDown on items)
    setTimeout(() => setSuggestionsVisible(false), 120);
  };

  const handleSuggestionClick = (name) => {
    setSelectedCustomer(name);
    setSearchTerm(name);
    setSuggestionsVisible(false);
  };

  const selectedData = selectedCustomer
    ? rewards.find(r => r.customer === selectedCustomer)
    : null;

  return (
    <div className="rewards-container">
      <h2>{translate("CUSTOMER_REWARDS_SUMMARY")}</h2>

      <div className="customer-select">
        {/* dropdown first (swapped) */}
        <label htmlFor="customer-select">{translate("CUSTOMER_REWARDS_SUMMARY")}: </label>
        <select id="customer-select" value={selectedCustomer} onChange={handleChange}>
          <option value="">{`-- Select a customer --`}</option>
          {customerNames.map(name => (
            <option key={name} value={name}>{name}</option>
          ))}
        </select>

        {/* search with suggestions */}
        <div className="search-wrapper">
          {/* label removed — search icon placed inside the input via CSS */}
          <input
            id="customer-search"
            className="customer-search"
            type="search"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={handleSearchChange}
            onFocus={handleSearchFocus}
            onBlur={handleSearchBlur}
            aria-label="Search customers"
            autoComplete="off"
          />
          {suggestionsVisible && filteredCustomerNames.length > 0 && (
            <ul className="suggestions" role="listbox" aria-label="Customer suggestions">
              {filteredCustomerNames.map((name) => (
                <li
                  key={name}
                  role="option"
                  className="suggestion-item"
                  onMouseDown={() => handleSuggestionClick(name)} /* onMouseDown avoids blur race */
                >
                  {name}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <Suspense fallback={<div>{translate("LOADING_CUSTOMER_DATA")}</div>}>
        {selectedData ? (
          <div className="customer-section" key={selectedData.customer}>
            <CustomerRewards {...selectedData} />
          </div>
        ) : (
          <div>{customerNames.length ? "Please select a customer to view details." : "No customer data available."}</div>
        )}
      </Suspense>
    </div>
  );
};

export default RewardsTable;