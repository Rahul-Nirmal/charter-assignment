import React from "react";
import { render, screen } from "@testing-library/react";
import MonthlyPointsList from "./MonthlyPointsList";

describe("MonthlyPointsList", () => {
  test("renders list items with month labels and points", () => {
    const monthlyPoints = [
      { month: "May 2025", points: 50 },
      { label: "Jun 2025", points: 30 },
      { monthKey: "2025-07", points: 20 },
    ];

    render(<MonthlyPointsList monthlyPoints={monthlyPoints} />);

    expect(screen.getByText(/May 2025/i)).toBeInTheDocument();
    expect(screen.getByText(/50 points/i)).toBeInTheDocument();
    expect(screen.getByText(/Jun 2025/i)).toBeInTheDocument();
    expect(screen.getByText(/30 points/i)).toBeInTheDocument();
    // fallback monthKey rendered as label when provided
    expect(screen.getByText(/2025-07/i)).toBeInTheDocument();
  });
});
