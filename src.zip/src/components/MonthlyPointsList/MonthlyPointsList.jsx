import React from "react";
import PropTypes from "prop-types";
import { translate } from "../../constant/constant";

const MonthlyPointsList = ({ monthlyPoints }) => {
  const list = Array.isArray(monthlyPoints) ? monthlyPoints : [];
  return (
    <table className="monthly-table">
      <thead>
        <tr>
          <th>{translate("MONTH_FALLBACK")}</th>
          <th>{translate("POINTS_LABEL")}</th>
        </tr>
      </thead>
      <tbody>
        {list.map((item, index) => {
          const label = item.month ?? item.label ?? item.monthKey ?? `${translate("MONTH_FALLBACK")} ${index + 1}`;
          const points = Number(item.points) || 0;
          return (
            <tr key={label + index}>
              <td>{label}</td>
              <td>{points}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

MonthlyPointsList.propTypes = {
  monthlyPoints: PropTypes.arrayOf(
    PropTypes.shape({
      month: PropTypes.string,
      label: PropTypes.string,
      monthKey: PropTypes.string,
      points: PropTypes.number,
    })
  ),
};

MonthlyPointsList.defaultProps = {
  monthlyPoints: [],
};

export default MonthlyPointsList;