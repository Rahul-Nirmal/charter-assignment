import RewardsTable from "./components/RewardsTable/RewardsTable";

function App() {
  return (
    <div className="App">
    <RewardsTable />
    </div>
  );
}

export default App;
