// Register custom jest-dom matchers globally for tests
import "@testing-library/jest-dom";
