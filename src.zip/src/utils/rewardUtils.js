import { useCallback, useMemo } from "react";

/**
 * Reward rules (standard):
 * - 2 points for every dollar spent over $100
 * - 1 point for every dollar spent over $50 (up to $100)
 */
export const calculatePoints = (amount = 0) => {
  let points = 0;
  if (amount > 100) {
    points += (amount - 100) * 2;
    points += 50; // for the $50-$100 range
  } else if (amount > 50) {
    points += amount - 50;
  }
  return Math.floor(points);
};

const toMonthKey = (isoDate) => {
  const dateObj = new Date(isoDate);
  if (Number.isNaN(dateObj.getTime())) return null;
  const year = dateObj.getFullYear();
  const monthStr = String(dateObj.getMonth() + 1).padStart(2, "0");
  return `${year}-${monthStr}`; // sortable key like '2025-08'
};

const monthLabel = (monthKey) => {
  const [yearStr, monthNumStr] = monthKey.split("-");
  const date = new Date(Number(yearStr), Number(monthNumStr) - 1, 1);
  return date.toLocaleString("default", { month: "short", year: "numeric" }); // e.g. "Aug 2025"
};

export const groupByCustomer = (transactions = []) => {
  const customerMap = new Map();

  for (const transaction of transactions) {
    const { customer, amount = 0, date } = transaction;
    if (!customer) continue;
    if (!customerMap.has(customer)) {
      customerMap.set(customer, {
        customer,
        transactions: [],
        monthlyMap: new Map(), // temp map monthKey -> points
        totalRewards: 0,
      });
    }
    const customerEntry = customerMap.get(customer);
    customerEntry.transactions.push(transaction);

    const monthKey = toMonthKey(date) || "unknown";
    const points = calculatePoints(amount);

    customerEntry.monthlyMap.set(
      monthKey,
      (customerEntry.monthlyMap.get(monthKey) || 0) + points
    );
    customerEntry.totalRewards += points;
  }

  // Build final array with sorted transactions and monthly array
  const result = [];
  for (const [, customerEntry] of customerMap.entries()) {
    customerEntry.transactions.sort(
      (leftTx, rightTx) => new Date(leftTx.date) - new Date(rightTx.date)
    );
    const monthly = Array.from(customerEntry.monthlyMap.entries())
      .sort((leftEntry, rightEntry) => leftEntry[0].localeCompare(rightEntry[0])) // sort by monthKey ascending
      .map(([monthKey, points]) => ({
        monthKey,
        label: monthLabel(monthKey),
        points,
      }));
    result.push({
      customer: customerEntry.customer,
      transactions: customerEntry.transactions,
      monthly,
      totalRewards: customerEntry.totalRewards,
    });
  }

  // sort customers alphabetically for stable UI
  result.sort((left, right) => left.customer.localeCompare(right.customer));
  return result;
};

/*
  New: hook that provides memoized function references for use in React components.
  Usage:
    const { calculatePoints: calc, groupByCustomer: group } = useRewardUtils();
    const grouped = useMemo(() => group(transactions), [transactions, group]);
*/
export const useRewardUtils = () => {
  // stable wrapper for calculatePoints
  const calculatePointsCallback = useCallback((amount = 0) => calculatePoints(amount), []);

  // stable wrapper for groupByCustomer (calls the pure function)
  const groupByCustomerCallback = useCallback(
    (transactions = []) => groupByCustomer(transactions),
    []
  );

  // return a memoized object so identity is stable across renders unless callbacks change
  return useMemo(
    () => ({
      calculatePoints: calculatePointsCallback,
      groupByCustomer: groupByCustomerCallback,
    }),
    [calculatePointsCallback, groupByCustomerCallback]
  );
};