import { useState, useEffect, useCallback } from "react";

const useTransactions = (url = "/data/transactions.json") => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchTransactions = useCallback(async (signal) => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(url, { signal });
      if (!response.ok) throw new Error(response.statusText || "Fetch error");
      const jsonData = await response.json();
      setTransactions(Array.isArray(jsonData) ? jsonData : []);
    } catch (caughtError) {
      if (caughtError.name !== "AbortError") {
        setError(caughtError);
        setTransactions([]);
      }
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    const controller = new AbortController();
    fetchTransactions(controller.signal);
    return () => controller.abort();
  }, [fetchTransactions]);

  const reload = () => {
    const controller = new AbortController();
    fetchTransactions(controller.signal);
  };

  return { transactions, loading, error, reload };
};

export default useTransactions;
