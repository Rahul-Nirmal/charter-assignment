export const STRINGS = {
  en: {
    CUSTOMER_REWARDS_SUMMARY: "Customer Rewards Summary",
    LOADING_CUSTOMER_DATA: "Loading customer data...",
    TRANSACTION_BREAKDOWN: "Transaction Breakdown",
    DATE: "Date",
    AMOUNT: "Amount ($)",
    POINTS_EARNED: "Points Earned",
    TOTAL_SPEND: "Total Spend",
    TOTAL_POINTS: "Total Points",
    POINTS_LABEL: "points",
    MONTH_FALLBACK: "Month",
  },
};

/**
 * Simple translator helper. Usage: translate('KEY', 'en')
 * Returns key if no translation found.
 */
export const translate = (key, lang = "en") => {
  return (STRINGS[lang] && STRINGS[lang][key]) || key;
};

export default STRINGS;
